const db = require("../config/db");

class Post {
  constructor(nimet, syntymavuosi, paino, kuva, laji, saavutukset) {
    this.nimet = nimet;
    this.syntymavuosi = syntymavuosi;
    this.paino = paino;
    this.kuva = kuva;
    this.laji = laji;
    this.saavutukset = saavutukset;
  }
  save() {
    let sql = `
        INSERT INTO urheilijat(
            nimet,
            syntymavuosi,
            paino,
            kuva,
            laji,
            saavutukset
        )
        VALUES(
            '${this.nimet}',
            '${this.syntymavuosi}',
            '${this.paino}',
            '${this.kuva}',
            '${this.laji}',
            '${this.saavutukset}'  
        )
        `;
    return db.execute(sql);
  }
  static findAll() {
    let sql = "SELECT * FROM urheilijat;";
    return db.execute(sql);
  }
  static findById(id) {
    let sql = `SELECT * FROM urheilijat WHERE id = ${id};`;
    return db.execute(sql);
  }
  static deleteById(id) {
    let sql = `DELETE FROM urheilijat WHERE id = ${id};`;
    return db.execute(sql);
  }
  static putById(id) {
    let sql = `UPDATE urheilijat SET nimet = '${this.nimet}', syntymavuosi = '${this.syntymavuosi}', paino = '${this.paino}', kuva = '${this.kuva}', laji = '${this.laji}', saavutukset = '${this.saavutukset}' WHERE id = ${id};`;
    return db.execute(sql);
  }
}

module.exports = Post;
