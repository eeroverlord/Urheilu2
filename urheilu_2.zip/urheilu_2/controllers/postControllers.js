const e = require("express");
const Post = require("../models/Post");

exports.getAllPosts = async (req, res, next) => {
  try {
    const [posts, _] = await Post.findAll();
    res.status(200).json({ count: posts.length, posts });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
exports.createNewPost = async (req, res, next) => {
  try {
    let { nimet, syntymavuosi, paino, kuva, laji, saavutukset } = req.body;
    let post = new Post(nimet, syntymavuosi, paino, kuva, laji, saavutukset);
    post = await post.save();
    res.status(201).json({ message: "Post created", post: post });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
exports.getById = async (req, res, next) => {
  try {
    const [post] = await Post.findById(req.params.id);
    res.status(200).json({ post });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
exports.deleteById = async (req, res, next) => {
  try {
    const [post] = await Post.deleteById(req.params.id);
    res.status(200).json({ post });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
exports.putById = async (req, res, next) => {
  try {
    let { nimet, syntymavuosi, paino, kuva, laji, saavutukset } = req.body;
    let post = new Post(nimet, syntymavuosi, paino, kuva, laji, saavutukset);
    let postID = req.params.id;
    post = await post.putById(postID);
    res.status(201).json({ message: "Post updated", post: post });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
